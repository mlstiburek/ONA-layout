# orchONA I/O interface
# author: Milan Lstiburek
# see Instructions.txt

#xxx 0 - Load libraries xxx
library(xlsx)
library(orchONA)

#- ?use clonal ID's (0) or plain numbers (1):
clone_ID <- 1 #clonal ID's provided in .xlsx sheet IDMAT (column 3)
NIT <- 100 #number of iterations of the ONA heuristics

#xxx 1 - Files xxx
setwd("D:/CZU/R_code/SO_designs/My_R_libraries/orchONA/IO_files")
inp_file <- "orchONA_import.xlsx"
exp_file <- "orchONA_export.xlsx"

#xxx Input from Excel xxx
inp_1 <- read.xlsx(inp_file, sheetName = "GRMAT", header = FALSE) # read the GRMAT sheet
GRMAT <- apply(as.matrix.noquote(inp_1),2,as.numeric)
inp_2 <- read.xlsx(inp_file, sheetName = "IDMAT", header = FALSE) # read the GRMAT sheet
x_1 <- apply(as.matrix.noquote(inp_2),2,as.character)
x_2 <- x_1[,1:2]
IDMAT <- mapply(x_2, FUN=as.numeric)
IDMAT <- matrix(data=IDMAT, ncol=2)
if (clone_ID == 0) rownames(IDMAT) <- x_1[,3]

#xxx Generate ONA scheme xxx
result <- orchONA(ID = IDMAT, GR = GRMAT, niter = NIT, weight = 99999)

#xxx Output to Excel xxx
if (clone_ID == 0) y_1 <- apply(as.matrix.noquote(result$ONA),2,as.character)
if (clone_ID == 1) y_1 <- apply(as.matrix.noquote(result$ONA),2,as.numeric)
write.xlsx(y_1, exp_file, sheetName = "ONA", col.names = FALSE, row.names = FALSE)
y_2 <- apply(as.matrix(result$PAIR),2,as.numeric)
write.xlsx(y_2, exp_file, sheetName = "PAIRS", col.names = FALSE, row.names = FALSE, append = TRUE)

#xxx Clear directory xxx
rm(list=setdiff(ls(), "result"))
